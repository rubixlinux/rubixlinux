/*
 * IAXy Provisioning software
 * 
 * Mark Spencer <markster@digium.com>
 * 
 * Copyright (C) 2003, Digium Inc.
 *
 * All rights reserved.
 * 
 */
 
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

int main(int argc, char *argv[])
{
	int s;
	struct sockaddr_in sin;
	char buf[1024];
	int res;
	int sinlen;
	s = socket(AF_INET, SOCK_DGRAM, 0);
	if (s < 0) {
		perror("socket");
		exit(1);
	}
	memset(&sin, 0, sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_port = ntohs(9999);
	if (bind(s, (struct sockaddr *)&sin, sizeof(sin))) {
		perror("bind");
		exit(1);
	}
	for(;;) {
		memset(buf, 0, sizeof(buf));
		sinlen = sizeof(sin);
		res = recvfrom(s, buf, sizeof(buf) - 1, 0, (struct sockaddr *)&sin, &sinlen);
		printf(buf);
	}
	exit(0);
}
